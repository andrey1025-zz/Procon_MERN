module.exports = {
    success: "success",
    failure: "failure",
    unauthorized: "unauthorized"
}