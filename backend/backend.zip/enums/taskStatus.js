module.exports = {
    Created: "created",
    Reviewed: "reviewed",
    NotStart: "notstart",
    Inprogress: "inprogress",
    Completed: "completed",
    Checked: "checked"
}