module.exports = {
    SupervisorRole: "Superintendent",
    ProjectManagerRole: "Project Manager",
    EngineerRole: "Engineer",
    MemberRole: "Member"
}